import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get user's orders
export const getUserOrders = query({
  args: { status: v.optional(v.string()) },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    if (args.status) {
      return await ctx.db
        .query("orders")
        .withIndex("by_user_status", (q) => q.eq("userId", userId).eq("status", args.status!))
        .order("desc")
        .collect();
    }

    return await ctx.db
      .query("orders")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
  },
});

// Place a new order
export const placeOrder = mutation({
  args: {
    marketSymbol: v.string(),
    type: v.string(),
    side: v.string(),
    amount: v.number(),
    price: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    // Get market info
    const market = await ctx.db
      .query("markets")
      .withIndex("by_symbol", (q) => q.eq("symbol", args.marketSymbol))
      .unique();

    if (!market) {
      throw new Error("Market not found");
    }

    const [baseAsset, quoteAsset] = args.marketSymbol.split("/");
    const orderPrice = args.price || market.currentPrice;
    const totalValue = args.amount * orderPrice;
    const fee = totalValue * 0.001; // 0.1% fee

    // Check if user has sufficient balance
    const requiredAsset = args.side === "buy" ? quoteAsset : baseAsset;
    const requiredAmount = args.side === "buy" ? totalValue + fee : args.amount;

    const wallet = await ctx.db
      .query("wallets")
      .withIndex("by_user_asset", (q) => q.eq("userId", userId).eq("asset", requiredAsset))
      .unique();

    if (!wallet || wallet.balance < requiredAmount) {
      throw new Error("Insufficient balance");
    }

    // Create the order
    const orderId = await ctx.db.insert("orders", {
      userId,
      marketSymbol: args.marketSymbol,
      type: args.type,
      side: args.side,
      amount: args.amount,
      price: args.type === "limit" ? orderPrice : undefined,
      status: args.type === "market" ? "filled" : "pending",
      filledAmount: args.type === "market" ? args.amount : 0,
      remainingAmount: args.type === "market" ? 0 : args.amount,
      totalValue,
      fee,
    });

    // Update wallet balances
    if (args.type === "market") {
      // Execute market order immediately
      if (args.side === "buy") {
        // Deduct quote asset, add base asset
        await ctx.db.patch(wallet._id, {
          balance: wallet.balance - totalValue - fee,
        });

        const baseWallet = await ctx.db
          .query("wallets")
          .withIndex("by_user_asset", (q) => q.eq("userId", userId).eq("asset", baseAsset))
          .unique();

        if (baseWallet) {
          await ctx.db.patch(baseWallet._id, {
            balance: baseWallet.balance + args.amount,
          });
        } else {
          await ctx.db.insert("wallets", {
            userId,
            asset: baseAsset,
            balance: args.amount,
            lockedBalance: 0,
          });
        }
      } else {
        // Deduct base asset, add quote asset
        await ctx.db.patch(wallet._id, {
          balance: wallet.balance - args.amount,
        });

        const quoteWallet = await ctx.db
          .query("wallets")
          .withIndex("by_user_asset", (q) => q.eq("userId", userId).eq("asset", quoteAsset))
          .unique();

        if (quoteWallet) {
          await ctx.db.patch(quoteWallet._id, {
            balance: quoteWallet.balance + totalValue - fee,
          });
        } else {
          await ctx.db.insert("wallets", {
            userId,
            asset: quoteAsset,
            balance: totalValue - fee,
            lockedBalance: 0,
          });
        }
      }
    } else {
      // Lock funds for limit order
      await ctx.db.patch(wallet._id, {
        balance: wallet.balance - requiredAmount,
        lockedBalance: wallet.lockedBalance + requiredAmount,
      });
    }

    return orderId;
  },
});

// Cancel an order
export const cancelOrder = mutation({
  args: { orderId: v.id("orders") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const order = await ctx.db.get(args.orderId);
    if (!order || order.userId !== userId) {
      throw new Error("Order not found");
    }

    if (order.status !== "pending") {
      throw new Error("Cannot cancel this order");
    }

    // Update order status
    await ctx.db.patch(args.orderId, {
      status: "cancelled",
    });

    // Unlock funds
    const [baseAsset, quoteAsset] = order.marketSymbol.split("/");
    const asset = order.side === "buy" ? quoteAsset : baseAsset;
    const amount = order.side === "buy" ? order.totalValue + order.fee : order.remainingAmount;

    const wallet = await ctx.db
      .query("wallets")
      .withIndex("by_user_asset", (q) => q.eq("userId", userId).eq("asset", asset))
      .unique();

    if (wallet) {
      await ctx.db.patch(wallet._id, {
        balance: wallet.balance + amount,
        lockedBalance: wallet.lockedBalance - amount,
      });
    }
  },
});
