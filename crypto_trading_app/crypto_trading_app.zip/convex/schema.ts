import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // User profiles with trading preferences
  profiles: defineTable({
    userId: v.id("users"),
    displayName: v.optional(v.string()),
    avatar: v.optional(v.string()),
    isAdmin: v.optional(v.boolean()),
    theme: v.optional(v.string()),
    tradingExperience: v.optional(v.string()),
    riskTolerance: v.optional(v.string()),
  }).index("by_user", ["userId"]),

  // Cryptocurrency markets
  markets: defineTable({
    symbol: v.string(), // e.g., "BTC/USD"
    baseAsset: v.string(), // e.g., "BTC"
    quoteAsset: v.string(), // e.g., "USD"
    currentPrice: v.number(),
    priceChange24h: v.number(),
    priceChangePercent24h: v.number(),
    volume24h: v.number(),
    marketCap: v.optional(v.number()),
    high24h: v.number(),
    low24h: v.number(),
    lastUpdated: v.number(),
    isActive: v.boolean(),
  }).index("by_symbol", ["symbol"])
    .index("by_base_asset", ["baseAsset"])
    .index("by_active", ["isActive"]),

  // User wallets/balances
  wallets: defineTable({
    userId: v.id("users"),
    asset: v.string(), // e.g., "BTC", "USD"
    balance: v.number(),
    lockedBalance: v.number(), // Amount locked in open orders
  }).index("by_user", ["userId"])
    .index("by_user_asset", ["userId", "asset"]),

  // Trading orders
  orders: defineTable({
    userId: v.id("users"),
    marketSymbol: v.string(),
    type: v.string(), // "market", "limit"
    side: v.string(), // "buy", "sell"
    amount: v.number(),
    price: v.optional(v.number()), // For limit orders
    status: v.string(), // "pending", "filled", "cancelled", "partial"
    filledAmount: v.number(),
    remainingAmount: v.number(),
    totalValue: v.number(),
    fee: v.number(),
  }).index("by_user", ["userId"])
    .index("by_market", ["marketSymbol"])
    .index("by_status", ["status"])
    .index("by_user_status", ["userId", "status"]),

  // Trade history
  trades: defineTable({
    buyOrderId: v.id("orders"),
    sellOrderId: v.id("orders"),
    buyerId: v.id("users"),
    sellerId: v.id("users"),
    marketSymbol: v.string(),
    amount: v.number(),
    price: v.number(),
    totalValue: v.number(),
    buyerFee: v.number(),
    sellerFee: v.number(),
  }).index("by_buyer", ["buyerId"])
    .index("by_seller", ["sellerId"])
    .index("by_market", ["marketSymbol"]),

  // Price history for charts
  priceHistory: defineTable({
    marketSymbol: v.string(),
    price: v.number(),
    volume: v.number(),
    timestamp: v.number(),
    interval: v.string(), // "1m", "5m", "1h", "1d"
  }).index("by_market_interval", ["marketSymbol", "interval"])
    .index("by_market_timestamp", ["marketSymbol", "timestamp"]),

  // Subscriptions/premium features
  subscriptions: defineTable({
    userId: v.id("users"),
    planType: v.string(), // "basic", "premium", "pro"
    status: v.string(), // "active", "cancelled", "expired"
    startDate: v.number(),
    endDate: v.number(),
    features: v.array(v.string()),
  }).index("by_user", ["userId"])
    .index("by_status", ["status"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
