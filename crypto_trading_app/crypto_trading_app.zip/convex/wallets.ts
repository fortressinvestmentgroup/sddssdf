import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get user's wallet balances
export const getUserWallets = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    return await ctx.db
      .query("wallets")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
  },
});

// Get specific wallet balance
export const getWalletBalance = query({
  args: { asset: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const wallet = await ctx.db
      .query("wallets")
      .withIndex("by_user_asset", (q) => q.eq("userId", userId).eq("asset", args.asset))
      .unique();

    return wallet?.balance || 0;
  },
});

// Initialize user wallet with default balances
export const initializeWallet = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    // Check if wallet already exists
    const existingWallets = await ctx.db
      .query("wallets")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    if (existingWallets.length > 0) {
      return; // Wallet already initialized
    }

    // Create default balances
    const defaultBalances = [
      { asset: "USD", balance: 10000, lockedBalance: 0 }, // $10,000 starting balance
      { asset: "BTC", balance: 0, lockedBalance: 0 },
      { asset: "ETH", balance: 0, lockedBalance: 0 },
      { asset: "ADA", balance: 0, lockedBalance: 0 },
    ];

    for (const balance of defaultBalances) {
      await ctx.db.insert("wallets", {
        userId,
        ...balance,
      });
    }
  },
});

// Update wallet balance (internal use)
export const updateBalance = mutation({
  args: {
    userId: v.id("users"),
    asset: v.string(),
    amount: v.number(),
    locked: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const wallet = await ctx.db
      .query("wallets")
      .withIndex("by_user_asset", (q) => q.eq("userId", args.userId).eq("asset", args.asset))
      .unique();

    if (!wallet) {
      // Create new wallet if it doesn't exist
      await ctx.db.insert("wallets", {
        userId: args.userId,
        asset: args.asset,
        balance: args.locked ? 0 : args.amount,
        lockedBalance: args.locked ? args.amount : 0,
      });
    } else {
      if (args.locked) {
        await ctx.db.patch(wallet._id, {
          lockedBalance: wallet.lockedBalance + args.amount,
        });
      } else {
        await ctx.db.patch(wallet._id, {
          balance: wallet.balance + args.amount,
        });
      }
    }
  },
});
