import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

// Get all active markets
export const getMarkets = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("markets")
      .withIndex("by_active", (q) => q.eq("isActive", true))
      .collect();
  },
});

// Get a specific market by symbol
export const getMarket = query({
  args: { symbol: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("markets")
      .withIndex("by_symbol", (q) => q.eq("symbol", args.symbol))
      .unique();
  },
});

// Get price history for a market
export const getPriceHistory = query({
  args: { 
    symbol: v.string(),
    interval: v.string(),
    limit: v.optional(v.number())
  },
  handler: async (ctx, args) => {
    const limit = args.limit || 100;
    return await ctx.db
      .query("priceHistory")
      .withIndex("by_market_interval", (q) => 
        q.eq("marketSymbol", args.symbol).eq("interval", args.interval)
      )
      .order("desc")
      .take(limit);
  },
});

// Update market prices (admin only)
export const updateMarketPrice = mutation({
  args: {
    symbol: v.string(),
    price: v.number(),
    volume24h: v.number(),
    high24h: v.number(),
    low24h: v.number(),
    priceChange24h: v.number(),
  },
  handler: async (ctx, args) => {
    const market = await ctx.db
      .query("markets")
      .withIndex("by_symbol", (q) => q.eq("symbol", args.symbol))
      .unique();

    if (!market) {
      throw new Error("Market not found");
    }

    const priceChangePercent24h = market.currentPrice > 0 
      ? (args.priceChange24h / market.currentPrice) * 100 
      : 0;

    await ctx.db.patch(market._id, {
      currentPrice: args.price,
      volume24h: args.volume24h,
      high24h: args.high24h,
      low24h: args.low24h,
      priceChange24h: args.priceChange24h,
      priceChangePercent24h,
      lastUpdated: Date.now(),
    });

    // Add to price history
    await ctx.db.insert("priceHistory", {
      marketSymbol: args.symbol,
      price: args.price,
      volume: args.volume24h,
      timestamp: Date.now(),
      interval: "1m",
    });
  },
});

// Initialize default markets
export const initializeMarkets = mutation({
  args: {},
  handler: async (ctx) => {
    const existingMarkets = await ctx.db.query("markets").collect();
    if (existingMarkets.length > 0) {
      return; // Markets already initialized
    }

    const defaultMarkets = [
      {
        symbol: "BTC/USD",
        baseAsset: "BTC",
        quoteAsset: "USD",
        currentPrice: 45000,
        priceChange24h: 1200,
        priceChangePercent24h: 2.74,
        volume24h: 28500000000,
        high24h: 46200,
        low24h: 43800,
        lastUpdated: Date.now(),
        isActive: true,
      },
      {
        symbol: "ETH/USD",
        baseAsset: "ETH",
        quoteAsset: "USD",
        currentPrice: 3200,
        priceChange24h: -85,
        priceChangePercent24h: -2.59,
        volume24h: 15200000000,
        high24h: 3350,
        low24h: 3150,
        lastUpdated: Date.now(),
        isActive: true,
      },
      {
        symbol: "ADA/USD",
        baseAsset: "ADA",
        quoteAsset: "USD",
        currentPrice: 0.52,
        priceChange24h: 0.03,
        priceChangePercent24h: 6.12,
        volume24h: 890000000,
        high24h: 0.55,
        low24h: 0.48,
        lastUpdated: Date.now(),
        isActive: true,
      },
    ];

    for (const market of defaultMarkets) {
      await ctx.db.insert("markets", market);
    }
  },
});
