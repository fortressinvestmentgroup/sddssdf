import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  HomeIcon, 
  ChartBarIcon, 
  CurrencyDollarIcon, 
  WalletIcon, 
  UserIcon 
} from '@heroicons/react/24/outline';
import {
  HomeIcon as HomeIconSolid,
  ChartBarIcon as ChartBarIconSolid,
  CurrencyDollarIcon as CurrencyDollarIconSolid,
  WalletIcon as WalletIconSolid,
  UserIcon as UserIconSolid
} from '@heroicons/react/24/solid';

const navItems = [
  { path: '/', label: 'Home', icon: HomeIcon, activeIcon: HomeIconSolid },
  { path: '/markets', label: 'Markets', icon: ChartBarIcon, activeIcon: ChartBarIconSolid },
  { path: '/trading', label: 'Trade', icon: CurrencyDollarIcon, activeIcon: CurrencyDollarIconSolid },
  { path: '/wallet', label: 'Wallet', icon: WalletIcon, activeIcon: WalletIconSolid },
  { path: '/profile', label: 'Profile', icon: UserIcon, activeIcon: UserIconSolid },
];

export default function BottomNavBar() {
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 md:hidden">
      <div className="flex justify-around items-center py-2">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path || 
            (item.path === '/trading' && location.pathname.startsWith('/trading'));
          const Icon = isActive ? item.activeIcon : item.icon;
          
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center py-2 px-3 rounded-lg transition-colors ${
                isActive 
                  ? 'text-blue-600 dark:text-blue-400' 
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              <Icon className="w-6 h-6" />
              <span className="text-xs mt-1">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
