import React from 'react';
import { useQuery } from 'convex/react';
import { api } from '../../convex/_generated/api';
import { Link } from 'react-router-dom';
import { ArrowUpIcon, ArrowDownIcon } from '@heroicons/react/24/solid';

export default function Markets() {
  const markets = useQuery(api.markets.getMarkets);

  if (!markets) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-4">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Markets</h1>
        <p className="text-gray-600 dark:text-gray-400">Explore cryptocurrency prices and trends</p>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700">
          <div className="grid grid-cols-4 gap-4 text-sm font-medium text-gray-500 dark:text-gray-400">
            <div>Asset</div>
            <div className="text-right">Price</div>
            <div className="text-right">24h Change</div>
            <div className="text-right">Volume</div>
          </div>
        </div>
        
        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          {markets.map((market) => (
            <Link
              key={market._id}
              to={`/trading/${market.symbol}`}
              className="block px-4 py-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              <div className="grid grid-cols-4 gap-4 items-center">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                    {market.baseAsset.charAt(0)}
                  </div>
                  <div>
                    <div className="font-medium text-gray-900 dark:text-white">{market.symbol}</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">{market.baseAsset}</div>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="font-medium text-gray-900 dark:text-white">
                    ${market.currentPrice.toLocaleString()}
                  </div>
                </div>
                
                <div className="text-right">
                  <div className={`flex items-center justify-end ${
                    market.priceChangePercent24h >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {market.priceChangePercent24h >= 0 ? (
                      <ArrowUpIcon className="w-3 h-3 mr-1" />
                    ) : (
                      <ArrowDownIcon className="w-3 h-3 mr-1" />
                    )}
                    {Math.abs(market.priceChangePercent24h).toFixed(2)}%
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    ${Math.abs(market.priceChange24h).toFixed(2)}
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="font-medium text-gray-900 dark:text-white">
                    ${(market.volume24h / 1000000).toFixed(1)}M
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
