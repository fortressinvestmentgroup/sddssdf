import React from 'react';
import { useQuery } from 'convex/react';
import { api } from '../../convex/_generated/api';

export default function Wallet() {
  const wallets = useQuery(api.wallets.getUserWallets);
  const markets = useQuery(api.markets.getMarkets);
  const orders = useQuery(api.orders.getUserOrders, {});

  if (!wallets || !markets) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const totalBalance = wallets.reduce((total, wallet) => {
    if (wallet.asset === 'USD') {
      return total + wallet.balance;
    }
    const market = markets.find(m => m.baseAsset === wallet.asset);
    return total + (wallet.balance * (market?.currentPrice || 0));
  }, 0);

  const recentOrders = orders?.slice(0, 10) || [];

  return (
    <div className="p-4 space-y-6">
      {/* Total Balance */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Total Portfolio Value</h2>
        <div className="text-3xl font-bold text-gray-900 dark:text-white">
          ${totalBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </div>
      </div>

      {/* Balances */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Balances</h3>
        <div className="space-y-4">
          {wallets.map((wallet) => {
            const market = markets.find(m => m.baseAsset === wallet.asset);
            const usdValue = wallet.asset === 'USD' 
              ? wallet.balance 
              : wallet.balance * (market?.currentPrice || 0);

            return (
              <div key={wallet._id} className="flex justify-between items-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold">
                    {wallet.asset.charAt(0)}
                  </div>
                  <div>
                    <div className="font-medium text-gray-900 dark:text-white">{wallet.asset}</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      {wallet.asset === 'USD' ? 'US Dollar' : `${wallet.asset} Token`}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-gray-900 dark:text-white">
                    {wallet.balance.toFixed(wallet.asset === 'USD' ? 2 : 8)} {wallet.asset}
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    ${usdValue.toFixed(2)} USD
                  </div>
                  {wallet.lockedBalance > 0 && (
                    <div className="text-xs text-orange-600 dark:text-orange-400">
                      {wallet.lockedBalance.toFixed(wallet.asset === 'USD' ? 2 : 8)} locked
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Orders */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Recent Orders</h3>
        {recentOrders.length === 0 ? (
          <p className="text-gray-500 dark:text-gray-400 text-center py-4">No orders yet</p>
        ) : (
          <div className="space-y-3">
            {recentOrders.map((order) => (
              <div key={order._id} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div>
                  <div className="font-medium text-gray-900 dark:text-white">
                    {order.side.toUpperCase()} {order.amount} {order.marketSymbol}
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    {new Date(order._creationTime).toLocaleDateString()}
                  </div>
                </div>
                <div className="text-right">
                  <div className={`px-2 py-1 rounded text-xs font-medium ${
                    order.status === 'filled' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' :
                    order.status === 'pending' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' :
                    'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                  }`}>
                    {order.status}
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    ${order.totalValue.toFixed(2)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
