import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery, useMutation } from 'convex/react';
import { api } from '../../convex/_generated/api';
import { toast } from 'sonner';

export default function Trading() {
  const { pair } = useParams();
  const [selectedMarket, setSelectedMarket] = useState(pair || 'BTC/USD');
  const [orderType, setOrderType] = useState<'market' | 'limit'>('market');
  const [side, setSide] = useState<'buy' | 'sell'>('buy');
  const [amount, setAmount] = useState('');
  const [price, setPrice] = useState('');

  const markets = useQuery(api.markets.getMarkets);
  const market = useQuery(api.markets.getMarket, { symbol: selectedMarket });
  const wallets = useQuery(api.wallets.getUserWallets);
  const orders = useQuery(api.orders.getUserOrders, {});
  const placeOrder = useMutation(api.orders.placeOrder);
  const cancelOrder = useMutation(api.orders.cancelOrder);

  const handlePlaceOrder = async () => {
    if (!amount || (orderType === 'limit' && !price)) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      await placeOrder({
        marketSymbol: selectedMarket,
        type: orderType,
        side,
        amount: parseFloat(amount),
        price: orderType === 'limit' ? parseFloat(price) : undefined,
      });
      
      toast.success('Order placed successfully');
      setAmount('');
      setPrice('');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to place order');
    }
  };

  const handleCancelOrder = async (orderId: string) => {
    try {
      await cancelOrder({ orderId: orderId as any });
      toast.success('Order cancelled');
    } catch (error) {
      toast.error('Failed to cancel order');
    }
  };

  if (!markets || !market) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const [baseAsset, quoteAsset] = selectedMarket.split('/');
  const baseWallet = wallets?.find(w => w.asset === baseAsset);
  const quoteWallet = wallets?.find(w => w.asset === quoteAsset);

  return (
    <div className="p-4 space-y-6">
      {/* Market Selector */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Select Market
        </label>
        <select
          value={selectedMarket}
          onChange={(e) => setSelectedMarket(e.target.value)}
          className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
        >
          {markets.map((m) => (
            <option key={m._id} value={m.symbol}>
              {m.symbol} - ${m.currentPrice.toLocaleString()}
            </option>
          ))}
        </select>
      </div>

      {/* Market Info */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">{market.symbol}</h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">
              ${market.currentPrice.toLocaleString()}
            </div>
            <div className={`text-sm ${market.priceChangePercent24h >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {market.priceChangePercent24h >= 0 ? '+' : ''}{market.priceChangePercent24h.toFixed(2)}%
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-gray-500 dark:text-gray-400">24h Volume</div>
            <div className="font-medium text-gray-900 dark:text-white">
              ${(market.volume24h / 1000000).toFixed(1)}M
            </div>
          </div>
        </div>
      </div>

      {/* Trading Form */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Place Order</h3>
        
        {/* Order Type */}
        <div className="flex space-x-2 mb-4">
          <button
            onClick={() => setOrderType('market')}
            className={`flex-1 py-2 px-4 rounded-lg font-medium ${
              orderType === 'market'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
            }`}
          >
            Market
          </button>
          <button
            onClick={() => setOrderType('limit')}
            className={`flex-1 py-2 px-4 rounded-lg font-medium ${
              orderType === 'limit'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
            }`}
          >
            Limit
          </button>
        </div>

        {/* Buy/Sell */}
        <div className="flex space-x-2 mb-4">
          <button
            onClick={() => setSide('buy')}
            className={`flex-1 py-2 px-4 rounded-lg font-medium ${
              side === 'buy'
                ? 'bg-green-600 text-white'
                : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
            }`}
          >
            Buy
          </button>
          <button
            onClick={() => setSide('sell')}
            className={`flex-1 py-2 px-4 rounded-lg font-medium ${
              side === 'sell'
                ? 'bg-red-600 text-white'
                : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
            }`}
          >
            Sell
          </button>
        </div>

        {/* Amount */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Amount ({baseAsset})
          </label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0.00"
            className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          />
          <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Available: {side === 'buy' ? (quoteWallet?.balance || 0).toFixed(2) : (baseWallet?.balance || 0).toFixed(8)} {side === 'buy' ? quoteAsset : baseAsset}
          </div>
        </div>

        {/* Price (for limit orders) */}
        {orderType === 'limit' && (
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Price ({quoteAsset})
            </label>
            <input
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder={market.currentPrice.toString()}
              className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
        )}

        {/* Total */}
        {amount && (
          <div className="mb-4 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <div className="flex justify-between text-sm">
              <span>Total:</span>
              <span className="font-medium">
                {(parseFloat(amount) * (orderType === 'limit' ? parseFloat(price || '0') : market.currentPrice)).toFixed(2)} {quoteAsset}
              </span>
            </div>
          </div>
        )}

        <button
          onClick={handlePlaceOrder}
          className={`w-full py-3 px-4 rounded-lg font-medium text-white ${
            side === 'buy' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'
          } transition-colors`}
        >
          {side === 'buy' ? 'Buy' : 'Sell'} {baseAsset}
        </button>
      </div>

      {/* Open Orders */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Open Orders</h3>
        {orders?.filter(o => o.status === 'pending').length === 0 ? (
          <p className="text-gray-500 dark:text-gray-400 text-center py-4">No open orders</p>
        ) : (
          <div className="space-y-3">
            {orders?.filter(o => o.status === 'pending').map((order) => (
              <div key={order._id} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div>
                  <div className="font-medium text-gray-900 dark:text-white">
                    {order.side.toUpperCase()} {order.amount} {order.marketSymbol.split('/')[0]}
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    {order.type === 'limit' ? `@ $${order.price}` : 'Market Order'}
                  </div>
                </div>
                <button
                  onClick={() => handleCancelOrder(order._id)}
                  className="px-3 py-1 text-sm bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
                >
                  Cancel
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
