import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AuthProvider } from "./contexts/AuthContext";
import Home from "./pages/Home";
import Markets from "./pages/Markets";
import Trading from "./pages/Trading";
import Profile from "./pages/Profile";
import Wallet from "./pages/Wallet";
import BottomNavBar from "./components/BottomNavBar";
import ProtectedRoute from "./components/ProtectedRoute";

export default function App() {
  return (
    <Router>
      <ThemeProvider>
        <AuthProvider>
          <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
            <header className="sticky top-0 z-10 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm h-16 flex justify-between items-center border-b shadow-sm px-4">
              <h2 className="text-xl font-semibold text-blue-600 dark:text-blue-400">CryptoTrade</h2>
              <Authenticated>
                <SignOutButton />
              </Authenticated>
            </header>
            <main className="flex-1 pb-20 md:pb-0">
              <Content />
            </main>
            <Authenticated>
              <BottomNavBar />
            </Authenticated>
            <Toaster />
          </div>
        </AuthProvider>
      </ThemeProvider>
    </Router>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/login" element={
        <Unauthenticated>
          <div className="flex items-center justify-center min-h-[80vh] p-8">
            <div className="w-full max-w-md mx-auto">
              <div className="text-center mb-8">
                <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Welcome to CryptoTrade</h1>
                <p className="text-xl text-gray-600 dark:text-gray-300">Sign in to start trading</p>
              </div>
              <SignInForm />
            </div>
          </div>
        </Unauthenticated>
      } />
      
      <Route path="/" element={
        <ProtectedRoute>
          <Home />
        </ProtectedRoute>
      } />
      
      <Route path="/markets" element={
        <ProtectedRoute>
          <Markets />
        </ProtectedRoute>
      } />
      
      <Route path="/trading/:pair?" element={
        <ProtectedRoute>
          <Trading />
        </ProtectedRoute>
      } />
      
      <Route path="/wallet" element={
        <ProtectedRoute>
          <Wallet />
        </ProtectedRoute>
      } />
      
      <Route path="/profile" element={
        <ProtectedRoute>
          <Profile />
        </ProtectedRoute>
      } />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
