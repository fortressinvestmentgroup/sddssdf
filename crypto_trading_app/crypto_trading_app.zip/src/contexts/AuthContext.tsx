import React, { createContext, useContext } from 'react';
import { useQuery } from 'convex/react';
import { api } from '../../convex/_generated/api';

interface AuthContextType {
  user: any;
  isLoggedIn: boolean;
  isAuthLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const user = useQuery(api.auth.loggedInUser);
  const isLoggedIn = !!user;
  const isAuthLoading = user === undefined;

  return (
    <AuthContext.Provider value={{ user, isLoggedIn, isAuthLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
